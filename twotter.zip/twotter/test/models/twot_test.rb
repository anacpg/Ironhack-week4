require 'test_helper'

class TwotTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
